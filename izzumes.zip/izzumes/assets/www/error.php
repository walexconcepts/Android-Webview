<!DOCTYPE html>
<html lang="en">
    <head>
        <title>izzumes.com</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width,initial-scale = 1.0,maximum-scale = 1.0,user-scalable=no" /> 

        <!--link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,600&amp;subset=latin-ext" rel="stylesheet"-->

        <!-- CSS -->
        <link href="file:///android_asset/www/css/main.css" rel="stylesheet">
		 <!--link href="css/font-awesome.min.css" rel="stylesheet"-->

        <!-- JS -->
        <script src="file:///android_asset/www/js/modernizr-2.8.3.min.js"></script>
        <script src="file:///android_asset/www/js/jquery-1.12.0.min.js"></script>
		
	<!-- Stylesheets--> 
 <style type="text/css">
 body{
  #background: #E1e1e1;
}

#cloud{
  width: 300px;
  max-width: 100%;
  height: 120px;
  background: #676767;

  background: -webkit-linear-gradient(-90deg,#676767 5%, #676767 100%);

  -webkit-border-radius: 100px;
  -moz-border-radius: 100px;
  border-radius: 100px;

  position: relative;

  margin: 150px auto 0;
  #opacity: .5;
  opacity: 1;
}

#cloud:before, #cloud:after{
  content: '';
  position:absolute;
  background: #676767;
  z-index: -1;
}

#cloud:after{
  width: 100px;
  height: 100px;
  top: -50px;
  left:50px;

  -webkit-border-radius: 100px;
  -moz-border-radius: 100px;
  border-radius: 100px;
}

#cloud:before{
  width: 120px;
  height: 120px;
  top: -70px;
  right: 50px;

  -webkit-border-radius: 200px;
  -moz-border-radius: 200px;
  border-radius: 200px;
}

.shadow {
  width: 300px;
  position: absolute;
  bottom: -10px;
  background: black;
  z-index: -1;

 
  #-webkit-box-shadow: 0 0 25px 8px rgba(0,0,0,0.4);
  #-moz-box-shadow: 0 0 25px 8px rgba(0,0,0,0.4);
  #box-shadow: 0 0 25px 8px rgba(0,0,0,0.4);
 

  -webkit-border-radius: 50%;
  -moz-border-radius: 50%;
  border-radius: 50%;

}

h2 {
  color: #fff;
  font-size: 25px;
  padding-top: 15px;
  text-align: center;
  margin: 5px auto;
}

h4 {
  color: #fff;
  font-size: 18px;
  margin: 0 auto;
  padding: 0;
  text-align: center;
}

 </style>
    </head>
    <body>
        <div class="site" id="page">
            <a class="skip-link sr-only" href="#main">Skip to content</a>

            <!-- Options headline effects: .rotate | .slide | .zoom | .push | .clip -->
            <section class="hero-section #hero-section--image clearfix clip">
                <div class="hero-section__wrap">
                    <!--div class="hero-section__option">
                        <img src="images/back.png" alt="Hero section image">
                    </div-->
                    <!-- .hero-section__option -->

                    <div class="container">
                        <div class="row">
                            <div class="offset-lg-2 col-lg-8">
                                <div class="title-01 title-01--11 text-center">
                                    <h2 class="title__heading">
									
									<!--img align="middle" style="width:84px;height:84px;border-radius:50%" src="images/unnamed.png"-->
									</h2>
									<h2 class="title__heading">
									<div id="cloud"> 
									<!--h2>
									No Connection :
									</h2-->
									<!--span>We are</span--->
                                        <h2 class="hero-section__words">
                                            <span style="font-sizt:45px;font-family: 'Montserrat',Sans-serif;color:#fff" class="title__effect is-visible"><span style="font-sizt:45px;font-family: 'Montserrat',Sans-serif;color:#fff">No&nbsp;</span>Internet:</span>
                                            <span style="font-sizt:45px;font-family: 'Montserrat',Sans-serif;color:#fff" class="title__effect"><span style="font-sizt:45px;font-family: 'Montserrat',Sans-serif;color:#fff">No&nbsp;</span>Internet:</span>
                                            <span style="font-sizt:45px;font-family: 'Montserrat',Sans-serif;color:#fff" class="title__effect"><span style="font-sizt:45px;font-family: 'Montserrat',Sans-serif;color:#fff">No&nbsp;</span>Internet:</span>
                                            
                                        </h2>
									<span class="shadow"></span>
									</div>
                                        
                                    </h2>
                                   
									<div style="clear:both;#color:#000;#font-family: 'Economica', #Agency fb;#font-size: 23px;" class="title__description">
									<!--Izzumes is an online markeplace to Sell & Buy Quickly! In Africa-->
									<br>
									</div>

                                    <!-- Options btn color: .btn-success | .btn-info | .btn-warning | .btn-danger | .btn-primary -->
                                    <!--div class="title__action"><a href="https://themewagon.com/themes/free-html5-splash-screen-template/" class="btn btn-success">Get the template</a></div-->
                                </div> <!-- .title-01 -->
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>

        <!--div class="button-group">
        	<a href="index-color.html" class="btn btn-outline-success button-sm">Color</a>
            <a href="index-slider.html" class="btn btn-outline-success button-sm">Slider</a>
            <a href="index-video.html" class="btn btn-outline-success button-sm">Video Background</a>
        </div--> 

        <!-- JS -->
        <script src="file:///android_asset/www/js/plugins/animate-headline.js"></script>
        <script src="file:///android_asset/www/js/main.js"></script>
    </body>
</html>
