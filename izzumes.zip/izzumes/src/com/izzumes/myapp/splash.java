package com.izzumes.myapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.view.View;

public class splash extends Activity {
    private static int SPLASH_TIME_OUT = 10000;
    private ProgressBar myProgressBar;
    private WebView myWebView;
    private String url = "file:///android_asset/www/index.html";

    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        myWebView = (WebView) findViewById(R.id.webviewsplash);
        myProgressBar = (ProgressBar) findViewById(R.id.progressbar);
        myWebView.getSettings().setJavaScriptEnabled(true);
        myWebView.loadUrl("file:///android_asset/www/splash.html");
		
        myWebView.setWebViewClient(new WebViewClient());
        myWebView.setWebChromeClient(new WebChromeClient() {
            public void onProgressChanged(WebView view, int newProgress) {
                super.onProgressChanged(view, newProgress);
                splash.this.myProgressBar.setProgress(newProgress);
                if (newProgress == 100) {
					myProgressBar.setVisibility(View.GONE);
                    //myProgressBar.setVisibility(8);
                } else {
                    myProgressBar.setVisibility(View.GONE);
                }
            }
        });
        myWebView.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                myProgressBar.setVisibility(8);
                view.loadUrl(url);
                return true;
            }
        });
        new Handler().postDelayed(new Runnable() {
            public void run() {
				Intent i = new Intent(splash.this, izzumes.class);
			    startActivity(i);
                finish();
            }
        }, SPLASH_TIME_OUT);
    }
}
