package com.izzumes.myapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;
import android.provider.MediaStore;
import android.support.v4.widget.SwipeRefreshLayout;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

public class izzumes extends Activity {
    	
	private static final int FILECHOOSER_RESULTCODE   = 1;
	private ValueCallback<Uri> mUploadMessage;
	private ValueCallback<Uri[]> mUploadMessages;
	private Uri mCapturedImageURI = null;
    private String mUrl = "";
    private ProgressBar myProgressBar;
    private WebView myWebView;
    private SwipeRefreshLayout swipe;
    private String url = "https://www.izzumes.com/";

    public boolean isConnected(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService("connectivity");
        NetworkInfo wifi = cm.getNetworkInfo(1);
        NetworkInfo mobile = cm.getNetworkInfo(0);
        if (mobile != null && mobile.isConnectedOrConnecting()) {
            return true;
        }
        if (wifi != null && wifi.isConnectedOrConnecting()) {
            return true;
        }
        if (mobile == null || !mobile.isConnectedOrConnecting() || wifi == null || !wifi.isConnectedOrConnecting()) {
            return false;
        }
        return true;
    }

    public AlertDialog.Builder buildDialog(Context c) {
        AlertDialog.Builder builder = new AlertDialog.Builder(c);
        builder.setTitle("No Internet Connection");
        builder.setMessage("You need to have Mobile Data or Wifi to access this. Otherwise press Back to continue or pull down to Refresh");
        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        return builder;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        myWebView = (WebView) findViewById(R.id.webview);
        myProgressBar = (ProgressBar) findViewById(R.id.progressbar);
        swipe = (SwipeRefreshLayout) findViewById(R.id.swipe);
        WebSettings settings = myWebView.getSettings();
        myWebView.getSettings().setJavaScriptEnabled(true);
        myWebView.getSettings().setLoadWithOverviewMode(true);
        myWebView.getSettings().setBuiltInZoomControls(false);
        myWebView.getSettings().setCacheMode(2);
        myWebView.getSettings().setDomStorageEnabled(true);
        myWebView.getSettings().setUseWideViewPort(true);
        myWebView.getSettings().setAllowFileAccess(true);
        myWebView.getSettings().setAllowContentAccess(true);
        myWebView.getSettings().setSupportZoom(false);
        myWebView.setScrollbarFadingEnabled(false);
		myWebView.setWebViewClient(new xWebViewClient());
        myWebView.setWebChromeClient(new xWebChromeClient() {
            // openFileChooser for Android 3.0+
            public void openFileChooser(ValueCallback<Uri> uploadMsg, String acceptType){
                mUploadMessage = uploadMsg;
                openImageChooser();
            }
            // For Lollipop 5.0+ Devices
            public boolean onShowFileChooser(WebView mWebView, ValueCallback<Uri[]> filePathCallback, WebChromeClient.FileChooserParams fileChooserParams) {
                mUploadMessages = filePathCallback;
                openImageChooser();
                return true;
            }
            // openFileChooser for Android < 3.0
            public void openFileChooser(ValueCallback<Uri> uploadMsg){
                openFileChooser(uploadMsg, "");
            }
            //openFileChooser for other Android versions
            public void openFileChooser(ValueCallback<Uri> uploadMsg, String acceptType, String capture) {
                openFileChooser(uploadMsg, acceptType);
            }

			private void openImageChooser() {
			try {
			File imageStorageDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "FolderName");
			if (!imageStorageDir.exists()) {
				imageStorageDir.mkdirs();
			}
			File file = new File(imageStorageDir + File.separator + "IMG_" + String.valueOf(System.currentTimeMillis()) + ".jpg");
			mCapturedImageURI = Uri.fromFile(file);

			final Intent captureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
			captureIntent.putExtra(MediaStore.EXTRA_OUTPUT, mCapturedImageURI);
			Intent i = new Intent(Intent.ACTION_GET_CONTENT);
			i.addCategory(Intent.CATEGORY_OPENABLE);
			i.setType("image/*");
			i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
			Intent chooserIntent = Intent.createChooser(i, "Image Chooser");
			chooserIntent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Parcelable[]{captureIntent});

			startActivityForResult(chooserIntent, FILECHOOSER_RESULTCODE);
			} catch (Exception e) {
			e.printStackTrace();
			}
			
			}

        });
        
        myWebView.setNestedScrollingEnabled(false);
        swipe.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            public void onRefresh() {
                String cUrl = myWebView.getUrl();
                if (isConnected(izzumes.this)) {
                    if (!myWebView.canGoBack()) {
                        myWebView.loadUrl(url);
                    } else if (cUrl.startsWith("file:") || cUrl.contains("android_asset")) {
                        myWebView.goBack();
                    } else if (myWebView.canGoBack() && myWebView.canGoForward()) {
                        myWebView.reload();
                    }
                    swipe.setRefreshing(true);
                    return;
                }
                buildDialog(izzumes.this).show();
                swipe.setRefreshing(false);
            }
        });
        if (isConnected(izzumes.this)) {
            myWebView.loadUrl(url);
        } else {
            myWebView.loadUrl("file:///android_asset/www/error.php");
        }
    }



    private class xWebChromeClient extends WebChromeClient {
        
		public void onProgressChanged(WebView view, int newProgress) {
            super.onProgressChanged(view, newProgress);
            myProgressBar.setProgress(newProgress);
            if (newProgress == 100) {
				//myProgressBar.setVisibility(View.GONE);
                myProgressBar.setVisibility(8);
            } else {
				//myProgressBar.setVisibility(View.VISIBLE);
                myProgressBar.setVisibility(0);
            }
        }
    }



    private class xWebViewClient extends WebViewClient {

        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            super.onPageStarted(view, url, favicon);
            mUrl = view.getUrl();
        }

        public void onPageFinished(WebView view, String url) {
            swipe.setRefreshing(false);
            mUrl = view.getUrl();
        }

        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError rerr) {
            try {
                myWebView.stopLoading();
                myWebView.loadUrl("file:///android_asset/www/error.php");
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (myWebView.canGoBack()) {
                myWebView.goBack();
            }
        }

        // For api level bellow 24
		@Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            myProgressBar.setVisibility(View.VISIBLE);
			/*
			if (url.contains("gh")) {
                    isHomePage = false;
                    return false;
                }
			*/
			if (url.startsWith("tel:") || url.startsWith("whatsapp:") || url.startsWith("callto:")) { 
                Intent intent = new Intent(Intent.ACTION_DIAL,Uri.parse(url)); 
                startActivity(intent); 
			}else if(url.startsWith("sms:")){
                    handleSMSLink(url);
                    return true;
                }else if(url.startsWith("http:") || url.startsWith("https:")) {
					view.loadUrl(url);
				}
			return true;
         }

         // From api level 24
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request){
				String url = request.getUrl().toString();
                myProgressBar.setVisibility(View.VISIBLE);
			/*			
			if (url.contains("izzumes.com")) {
                    isHomePage = false;
                    return false;
                }
			*/
			if (url.startsWith("tel:") || url.startsWith("whatsapp:") || url.startsWith("callto:")) { 
                Intent intent = new Intent(Intent.ACTION_DIAL,Uri.parse(url)); 
                startActivity(intent); 
			}else if(url.startsWith("sms:")){
                    handleSMSLink(url);
                    return true;
                }else if(url.startsWith("http:") || url.startsWith("https:")) {
					view.loadUrl(url);
				}
			return true;
            }
    }

    
    
    
	
	
	
	
	
	
	
	
	
	
	
	public void onActivityResult(final int requestCode, final int resultCode, final Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILECHOOSER_RESULTCODE) {

            if (null == mUploadMessage && null == mUploadMessages) {
                return;
            }

            if (null != mUploadMessage) {
                handleUploadMessage(requestCode, resultCode, data);

            } else if (mUploadMessages != null) {
                handleUploadMessages(requestCode, resultCode, data);
            }
        }

    }
	
	
    private void handleUploadMessage(final int requestCode, final int resultCode, final Intent data) {
        Uri result = null;
        try {
            if (resultCode != RESULT_OK) {
                result = null;
            } else {
                // retrieve from the private variable if the intent is null

                result = data == null ? mCapturedImageURI : data.getData();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        mUploadMessage.onReceiveValue(result);
        mUploadMessage = null;

        // code for all versions except of Lollipop
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) {

                result = null;

                try {
                    if (resultCode != RESULT_OK) {
                        result = null;
                    } else {
                        // retrieve from the private variable if the intent is null
                        result = data == null ? mCapturedImageURI : data.getData();
                    }
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "activity :" + e, Toast.LENGTH_LONG).show();
                }

                mUploadMessage.onReceiveValue(result);
                mUploadMessage = null;
            }

        } // end of code for all versions except of Lollipop

	    private void handleUploadMessages(final int requestCode, final int resultCode, final Intent data) {
        Uri[] results = null;
        try {
            if (resultCode != RESULT_OK) {
                results = null;
            } else {
                if (data != null) {
                    String dataString = data.getDataString();
                    ClipData clipData = data.getClipData();
                    if (clipData != null) {
                        results = new Uri[clipData.getItemCount()];
                        for (int i = 0; i < clipData.getItemCount(); i++) {
                            ClipData.Item item = clipData.getItemAt(i);
                            results[i] = item.getUri();
                        }
                    }
                    if (dataString != null) {
                        results = new Uri[]{Uri.parse(dataString)};
                    }
                } else {
                    results = new Uri[]{mCapturedImageURI};
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        mUploadMessages.onReceiveValue(results);
        mUploadMessages = null;
    }

    /* access modifiers changed from: protected */
    public void handleSMSLink(String url2) {
        Intent intent = new Intent("android.intent.action.SENDTO");
        String phoneNumber = url2.split("[:?]")[1];
        if (!TextUtils.isEmpty(phoneNumber)) {
            intent.setData(Uri.parse("smsto:" + phoneNumber));
        } else {
            intent.setData(Uri.parse("smsto:"));
        }
        if (url2.contains("body=")) {
            String smsBody = url2.split("body=")[1];
            try {
                smsBody = URLDecoder.decode(smsBody, "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            if (!TextUtils.isEmpty(smsBody)) {
                intent.putExtra("sms_body", smsBody);
            }
        }
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        }
    }

    //onBackPressed	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
	if(isConnected(izzumes.this)) {
	if ((keyCode == KeyEvent.KEYCODE_BACK) && myWebView.canGoBack()) {
	myWebView.goBack();
	return true;
	}else{
	finish();
	return true;
	}	
	}else{
	buildDialog(izzumes.this).show();
	}  
	return myWebView.onKeyDown(keyCode, event);
	}
	
}
